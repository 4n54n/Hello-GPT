VERTEX_HTTP_OPTIONS = {
    'api_version': 'v1beta1',
    'base_url': 'https://us-central1-aiplatform.googleapis.com/',
}
MLDEV_HTTP_OPTIONS = {
    'api_version': 'v1beta',
    'base_url': 'https://generativelanguage.googleapis.com/',
}
