# __init__.py
# Simply imports the main plugin class
from .hello_gpt import HelloGPTPlugin
